const express = require("express");
const app = express();
app.get("/", (req, res) => {
    res.set("content-type", "text/plain");
    res.send("<h1>Hello</h1>");
});
//res.write karyu hoi to sen blank rakhvu pade
app.get("/about", (req, res) => {
    res.set("content-type", "text/html");
    res.write("Hello");
    // res.send("<h1> Hello from home</h1>");
    //res.write ("hello");
    res.send()
});
app.listen(5504, () => {
    console.log("server started http://localhost:5504/");
});