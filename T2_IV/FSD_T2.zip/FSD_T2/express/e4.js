//creating a table 
const express = require("express")
const app = express();
student = {
    u1: [{ name: "LJU", id: 2 },
    { name: "LJU1", id: 3 },
    { name: "LJU2", id: 4 },
    { name: "LJU3", id: 5 },
    { name: "LJU4", id: 6 }]
}
app.get("/student", (req, res) => {
    res.set("content-type", "text/html")
    res.write("<center><table cellspacing='5px'cellpadding = '8px' border = '5px solid coral'; bgcolor='teal'; ><tr><th>Name</th><th>ID</th></tr>")
for (i of student.u1) {
        res.write("<tr><td>" + i.name + "</td>")
        res.write("<td>" + i.id + "</td></tr>")
    }
res.write("</table></center>")
res.send()
}).listen(6767, ()=>{
    console.log("for the show output in http://localhost:6767/student")
})