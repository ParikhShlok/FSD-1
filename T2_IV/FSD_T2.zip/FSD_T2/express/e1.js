var express=require("express")
var e=express()
e.get('/',function(req,res){
    // res.set('content-type','text/html') // first method to set res
    // res.setHeader("content-type","text/html") //second method to set res
    // res.type(".html")// third method(text/html)
    res.type("text/html")
    res.send("<h1> hello world </h1>")

})
e.listen(3000)