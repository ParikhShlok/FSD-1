const express = require("express");
const app = express();
app.get('/data',(req,res)=>{
    const name=req.query.name;
    const age=req.query.age;
    res.send("name: "+name+"age: "+age)
}).listen(5000)