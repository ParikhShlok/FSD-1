//sorting
const express = require("express")
const app = express();
student = [{ name: "abc", age: 28 },
{ name: "def", age: 40 },
{ name: "xyz", age: 50 }]
//home page for showing an array
app.get("/", (req, res) => {
    res.send(student);
})
//sort page for descending
app.get("/sort", (req, res) => {
    res.set("content-type", "text/html")
    var des = student.sort((a, b) => b.age - a.age) //for descending
    // var des = student.sort((a, b) => a.age - b.age)//for ascending
    for (k of des) {
        res.write("<center><h2>" + k.name + " = " + k.age + "</h2></center>")
    }
    res.send()
})
app.listen(5139, ()=>{
    console.log("for showing the what actual array http://localhost:5139")
    console.log("for showing the sort value hit the http://localhost:5139/sort")
})