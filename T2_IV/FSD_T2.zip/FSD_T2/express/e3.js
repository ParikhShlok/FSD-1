//Send JSON object using res.write
const express = require("express")
const app = express();
student = { name: "LJU", age: 28 }
app.get("/", (req, res) => {
    //first method
    // res.write(JSON.stringify(student))
    // res.send()
    //second method
    res.send(student)
})
app.listen(6767)