var express=require("express")
var app=express()
app.use(express.static(__dirname,{index:"p1.html"}))
app.get("/process_get",(req,res)=>{
    var fn=req.query.firstname;
    var ln=req.query.lastname;
    console.log(req.query)
    res.send(`welcome ${fn} ${ln}`)
})
app.listen(7676,()=>{
    console.log("open in this server http://localhost:7676")
})