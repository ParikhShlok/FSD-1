var express=require("express")
var app=express()
app.use(express.static(__dirname,{index:"p1.html"}))
app.post("/process_post",(req,res)=>{
    var fn=req.body.firstname;
    var ln=req.body.lastname;
    console.log(req.body)
    res.send(`welcome ${fn} ${ln}`)
})
app.listen(7540,()=>{
    console.log("open in this server http://localhost:7540")
})