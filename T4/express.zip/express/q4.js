//QUESTION 4 ANSWER
const express = require('express');
const app = express();
const entrylog = (req, res, next) => {
    console.log("Student na divas kharab thaya");
    next();
};
const checkid = (req, res, next) => {
    const hasid=false;
    if(hasid){
        req.student="popat";
        console.log("id pan verified thai gai")
    }
    else{
        res.send("reva de bhai divas saro jai chhe to id denied")
    }
    next();
};
app.use("/class",entrylog,checkid);
app.get("/class",(req,res)=>{
    res.send(`welcome ${req.student} to division B7`)
})
app.listen(6124,()=>{
    console.log("Server running at http://localhost:6124/class")
})