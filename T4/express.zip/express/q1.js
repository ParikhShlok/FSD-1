//these is first question that in pdf
//1
const express = require("express");
const app = express();
app.get("/",(req,res)=>{
    res.send(`<h1> user form </h1>
        <h3> create user</h3>
        <form action="/user" method="POST"/>
        <input type="text" name="name" placeholder="enter name"/>
        <button type="submit">create</button>
        </form> `)
})

app.post("/user",(req,res)=>{
    const name=req.body.name;
    req.send("user created with name:"+name)
}).listen(6767)