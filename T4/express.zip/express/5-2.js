//this is for all files in folder and js file is out of folder 
//second type of folder
const express=require("express")
const e=express()
e.use(express.static("frontend"))//write folder name if index.html if not so follow relative method
e.listen(5139,()=>{
    console.log("open in this server http://localhost:5139")
})