//QUESTION 2 ANSWER
const express = require('express');
const app = express();

// Dynamic route parameter: :id
app.get('/user/:id', (req, res) => {
    // 1. Extract route parameter
    const userid = req.params.userid;

    // 2. Extract query parameters (?name=...&age=...)
    const { name, age } = req.query;

    // 3. Return JSON response
    res.json({
        message:"data received",
        params: {id:userid},
        query: {name,age}
    });
});

app.listen(5000, () => {
    console.log(`Server running at http://localhost:5000`);
});

// http://localhost:5000/user/44?name=shlok&age=19