//this is for all files in same 
//first folder structure
const express=require("express")
const e=express()
//folder structure connect with js 
//when i run this file means runs index.html
//by default it execute index.html file
// e.use(express.static(__dirname))--this is for absolute path

e.use(express.static(__dirname,{index:"5-1.html"}))//relative path
e.listen(5050,()=>{
    console.log("open in this server http://localhost:5050")
})