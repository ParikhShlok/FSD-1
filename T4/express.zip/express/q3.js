//QUESTION 3 ANSWER
const express = require('express');
const app = express();

// Middleware 1: Adds student name
const addName = (req, res, next) => {
    req.studentName = "Parikh Shlok";
    console.log("name added");
    next();
};

// Middleware 2: Adds college name
const addCollege = (req, res, next) => {
    req.college = "LJ University";
    console.log("clg added");
    next();
};

// Middleware 3: Adds marks
const addMarks = (req, res, next) => {
    req.total=40+50;
    console.log("marks added")
    next();
};

// Apply middlewares to the route
app.get('/student', addName, addCollege, addMarks, (req, res) => {
    // Final route displays all values passed via req
    res.send("Student name:"+req.studentName+"<br>College:"+req.college+"<br>Marks:"+req.total);
});

app.listen(9696, () => {
    console.log(`Server running at http://localhost:9696/student`);
});
