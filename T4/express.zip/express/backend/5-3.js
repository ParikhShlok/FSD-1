//third type of folder structure
const express=require("express")
const e=express()
const path = require("path")
sp=path.join(__dirname,"../")
e.listen(5393,()=>{
    console.log("open in this server http://localhost:5393")
})

//in fourth where all files are in different folder
// sp=path.join(__dirname,"../frontend")
